# 🚀 Agentic App - Python智能代理系统

这是一个基于 LangChain 的智能代理系统，实现多轮、交互式、自我优化的复杂任务处理。系统通过反应式工作流能够理解用户意图，动态补充参数，调用工具完成查询，并通过评估循环确保输出质量。

## ✨ 核心特性
- 🎯 **意图识别与参数补全**: 自动分析用户意图，动态补充参数
- 🔄 **反应式工作流**: 基于LangGraph的状态机，支持评估迭代优化
- 🛠️ **动态工具系统**: 配置驱动的工具生成，支持RAG知识库检索
- 🔌 **MCP多服务器集成**: 支持连接多个MCP服务器，动态加载外部工具
- 💾 **记忆持久化**: SQLite/JSON双重存储，多用户对话管理
- 🌐 **实时交互**: WebSocket流式API，支持工具调用状态可视化
- 🎤 **语音识别**: 基于Whisper的实时语音转文字
- 🖼️ **多模态交互**: 支持图片上传和识别，文本+图片混合输入
- 📝 **文档生成**: 智能生成各类统计报告文档

## 📋 核心能力矩阵

### 交互式对话能力
- **意图识别**: 自动分析用户查询目的和参数需求
- **参数补全**: 智能识别缺失参数并主动询问用户
- **多轮对话**: 保持上下文连贯性，支持复杂任务分解
- **多模态**: 支持文本+图片混合输入，智能理解图片内容

### 语音识别能力
- **语音转写**: 基于Whisper模型语音识别
- **多语言支持**: 中文、英文等多语言识别
- **文本纠错**: 集成LLM进行语音识别后文本纠错
- **模型选择**: 支持tiny/base/small/medium/large多种模型

### 工作流引擎
- **状态机驱动**: 基于LangGraph构建的反应式工作流
- **评估迭代**: 自动评估回答质量，支持多次迭代优化
- **条件路由**: 根据参数完整性和评估结果智能路由

### 工具系统
- **RAG检索**: 集成Dify知识库，支持语义搜索和精读
- **动态工具**: 基于JSON配置动态生成工具，支持热更新
- **MCP集成**: 支持连接多个MCP服务器，动态加载外部工具
- **工具链**: 支持多工具链式调用，处理复杂查询

### 记忆管理
- **双重持久化**: SQLite（生产）和JSON（开发）两种存储方案
- **多用户支持**: 基于user_id和session_id的会话隔离
- **记忆窗口**: 可配置的对话历史保留长度

### 文档生成能力
- **智能生成**: 根据数据模板自动生成Word文档
- **统计报告**: 支持安防、能耗、运营等多类型报告
- **流式输出**: 支持生成过程实时反馈

## 🏗️ 系统架构

### 架构概览
系统采用分层架构设计，核心工作流基于LangGraph状态机：

```
┌─────────────┐   ┌─────────────┐   ┌─────────────┐
│  意图识别   │ → │  参数补全   │ → │  工具执行   │
└─────────────┘   └─────────────┘   └─────────────┘
       ↑                   ↓                 ↓
       │              ┌─────────────┐   ┌─────────────┐
       └──────────────│ 评估迭代    │ ← │  结果评估   │
                      └─────────────┘   └─────────────┘
                               ↓
                       ┌─────────────┐
                       │  最终答案   │
                       └─────────────┘
```

### 数据流转
1. **输入解析**: 用户查询 → 意图识别 → 参数分析
2. **交互补全**: 参数不足 → 用户询问 → 参数获取
3. **工具执行**: 调用RAG/动态工具 → 结果处理
4. **质量评估**: 回答评估 → 判断是否充分
5. **结果输出**: 最终答案生成 → 流式返回

详细工作流图: [workflow.png](workflow.png)

## 🎯 意图识别与参数提取

针对**人员态势 / 安防态势 / 食堂管理 / 车辆态势**四个园区业务模块，系统采用「**Embedding 小模型意图分类 + 正则规则参数抽取 + Handler 多轮追问补参 + LangGraph 状态机编排**」的组合方案，实现轻量、可解释、低延迟的意图识别与参数提取；通用业务则走 LLM 提示词方案（见「通用工具参数校验」）。

### 整体流程

```
用户输入 query
   │
   ├─ classify_intent()              顶层意图：person_status / security_status / canteen_status / vehicle_status / other
   │
   ├─ 对应 Handler.extract_slots()   抽取 query_type / person_name / date / area / meal 等参数(slots)
   │
   ├─ IntentState(session_state)     保存多轮追问状态(module, slots, missing_params, ask_count ...)
   │
   └─ LangGraph 图                   check_missing_params → ask_param / check_date → call_tool(MCP) → LLM 组织回答
```

### 1. 顶层意图识别（Embedding 小模型）

代码：[agent/intent/classifier.py](agent/intent/classifier.py)

- **模型**：`BAAI/bge-small-zh-v1.5`（sentence-transformers），路径由环境变量 `INTENT_MODEL_PATH` 指定，容器内可挂载本地模型避免联网下载
- **语料**：每个模块维护一份按子类型分组的示例语料库（`*_STATUS_EXAMPLES`，如 [PERSON_STATUS_EXAMPLES](agent/intent/classifier.py#L54)），所有示例向量的**归一化平均向量**即该意图的「中心向量」
- **判定**：一次编码用户输入，分别与四个意图中心向量计算余弦相似度（向量已归一化，点积即余弦），取最高分；**只有最高分超过该意图的阈值才命中**，否则归为 `other`
- **阈值**：四个意图阈值统一为 `0.65`（`*_STATUS_THRESHOLD`），语料不足时可调低

| 顶层意图 | intent | 子类型（query_type / event_type） |
|---|---|---|
| 人员态势 | person_status | location / trace / realtime / enter / leave / flow / structure / abnormal / count |
| 安防态势 | security_status | alarm_list / alarm_detail / intrusion / patrol / video / access / fire / device / abnormal |
| 食堂管理 | canteen_status | dish_rank（菜品热度）/ week_menu（菜谱）/ dining_count（就餐人数） |
| 车辆态势 | vehicle_status | parking_space / traffic_flow / parking_structure / official_vehicle / parking_duration_rank / parking_monitor / vehicle_access_record / count |

> **性能注意**：SentenceTransformer 的加载与 encode 是同步阻塞操作，模型通过 `get_classifier()` **单例加载一次**，并在 `run_in_executor` 线程池中执行，避免阻塞 Uvicorn 主事件循环 / WebSocket。

### 2. 子类型识别

- **人员 / 车辆**：**正则为主、分类器兜底** —— `extract_*_slots` 先用正则抽取 `query_type`；仅当正则落到兜底类型（`count`）时，才调用 `classify_sub_type` / `classify_vehicle_sub_type` 做 embedding 判定，分数 ≥ `0.6`（`SUB_TYPE_THRESHOLD`）则覆盖正则结果
- **安防 / 食堂**：当前以正则判定 `event_type` 为主，后续可对称扩展分类器兜底

### 3. 参数抽取（Slot 抽取）

代码：[agent/intent/slots.py](agent/intent/slots.py)

**通用 slot 解析器：**

- `parse_time_slot(query)`：时间解析。先手工处理口语化时间（近N天 / 本周 / 上周 / 本月 / 上个月 / 昨天 / 前天 等直接转成 `{start_time, end_time}` 时间区间），再交给 `jionlp.parse_time` 兜底。返回结构：
  - `time_type="span" / "point"`：可直接查询的具体时间区间
  - `time_type="vague"`：模糊时间（如"最近几天"），附带候选 `options`，由图中 `vague_date` 节点追问确认
  - `time_type="future"`：未来时间（明天/后天），由图中 `future_date` 节点提示不可查
- `parse_area_slot(query)`：区域别名词典映射（如"A座 / A楼" → 标准区域"A栋"）
- `parse_meal_slot(query)`：餐次别名词典映射（"早饭 / 早" → "早餐"）
- `extract_person_name(query)`：**员工名单精确匹配**，避免正则把"一下人员"等通用词错当人名
- `_parse_chinese_number()`：中文数字（一~九十九）转阿拉伯数字

**各模块 slots：**

| 模块 | 抽取函数 | slots 结构 | 判定要点 |
|---|---|---|---|
| 人员态势 | `extract_person_status_slots` | query_type, person_name, date, area | query_type 按 轨迹→位置→异常→流动→进入→离开→结构→实时→count 的**优先级正则**判定 |
| 安防态势 | `extract_security_status_slots` | event_type=alarm_list, date | 当前仅告警列表，date 映射为 MCP 参数 `{startTime, endTime}` |
| 食堂管理 | `extract_canteen_status_slots` | event_type, date, meal | 按「人数 → 热度排行 → 菜谱」优先级判定，兜底 week_menu |
| 车辆态势 | `extract_vehicle_status_slots` | query_type, date, area | 按 停车位→车流量→结构→公车→时长排名→监控→通行记录→count 优先级正则判定 |

### 4. 意图处理器 Handler（多轮追问）

代码：[agent/intent/handlers/](agent/intent/handlers/)（基类 [base.py](agent/intent/handlers/base.py)）

每个模块一个 Handler，统一继承 `IntentHandler` 抽象基类，职责：

| 方法 | 说明 |
|---|---|
| `extract_slots(query)` | 从用户输入抽取本模块参数 |
| `is_related(state, query)` | 追问阶段判断用户回复是否与当前任务相关（按缺人名/时间/区域的关键词判定；连续不相关累计超过 `MAX_UNRELATED=3` 次则放弃任务） |
| `handle_reply(state, query, llm)` | 处理追问轮回复，增量更新 slots、重新计算 `missing_params` |
| `_get_missing_params(slots)` | 判断还缺哪些必填参数（人员态势的 location/trace **必须有人名**；安防/食堂**必须有时段**；车辆态势当前不强制） |
| `generate_question(state)` | 按缺失参数优先级生成追问问题 |

Handler 还内置了确认逻辑：`_pending_confirm`（人员/车辆后端仅支持今日数据时，询问"是否为您展示今日X？"）、`_pending_date_clarify`（模糊时间范围确认），并识别同意 / 拒绝（`DECLINE_KEYWORDS`）关键词。同意判定用整句白名单（`base.is_confirm_agree`，去标点与结尾语气词后须与确认语完全相等），不用子串匹配——确认等待期的「查一下人员位置」这类新查询不能被单字「查」误吞成同意（2026-09-23 冒烟 T4）。

### 5. 会话状态 IntentState

代码：[memory/session_state.py](memory/session_state.py)

`IntentState` dataclass 保存多轮追问状态：`module`（当前模块）、`slots`（已抽取参数）、`missing_params`（缺失参数）、`ask_count`（追问次数，>3 放弃）、`unrelated_count`（连续不相关次数）、`last_question`（上次问题）、`original_query`（用户原话）、`done`。按 `user_id:session_id` 存入 `SessionStateManager`（默认 5 分钟过期）。

### 6. LangGraph 状态机编排

代码：[graph/person_status_langgraph.py](graph/person_status_langgraph.py)、[graph/security_status_langgraph.py](graph/security_status_langgraph.py)、[graph/canteen_status_langgraph.py](graph/canteen_status_langgraph.py)、[graph/vehicle_status_langgraph.py](graph/vehicle_status_langgraph.py)（四个模块结构一致）

```
init → check_missing_params
    ├─ ask_param        缺失参数：追问（ask_count > 3 → give_up）
    ├─ check_date
    │    ├─ future_date 未来时间：直接提示不可查
    │    ├─ vague_date  模糊时间：让用户确认具体范围（近三天/近一周/近一个月）
    │    └─ check_confirm → confirm_today  人员/车辆：非今天查询先确认是否看今日数据
    │         └─ call_tool → finalize → END
```

- `call_tool` 通过 `_JAVA_TOOL_MAP` 把 Python 的 query_type / event_type 映射到 **Java MCP 工具名**（如 `person_status:getTodayPersonnelAffairs`、`canteen:getWeekMenu`），工具从 `mcp_client/mcp_server_config.yaml` 动态加载
- 工具返回后优先用 LLM 按查询类型组织自然语言回答；**LLM 不可用 / 失败时降级为 Python 正则提取**（如人员态势按 query_type 提取"实时在园人数 / 今日进入人数"等字段），保证流程不断

### 7. app.py 路由

`/chat` WebSocket 中（[app.py](app.py)）：

1. 若当前会话存在**进行中的态势任务**（`module` ∈ 四个模块），直接调用对应 Handler 的 `handle_reply` 处理追问
2. 否则调用 `classify_intent(query)` 预判顶层意图，命中四个模块则 `extract_slots` → 构造 `IntentState` → 进入对应 LangGraph 图
3. 其它意图走原有 LLM pipeline

### 8. 通用工具参数校验（LLM 提示词方案）

非态势类业务走 LLM 方案：

- [agent/get_intent_and_select_tools_prompt.py](agent/get_intent_and_select_tools_prompt.py)：LLM 充当「工具参数校验器」，结合工具 JSON 描述、用户最新输入与已理解意图，输出 `intent_desc` + `intent_get_result`（内含 `params_got` / `missing_params`），支持多轮补参。相对时间（今天 / 本周 / 本月）视为已获得参数不追问；含"坏了 / 故障 / 报修"等关键词时直接判定为园区报修工单生成
- [agent/ask_for_param_prompt.py](agent/ask_for_param_prompt.py)：参数缺失时生成礼貌的追问文本（面向语音输入，选择方便口述的格式）

## 🛠️ 技术栈

### 技术栈

### 核心框架
- **LangChain + LangGraph**: 代理框架和工作流引擎
- **FastAPI**: Web服务器和WebSocket支持
- **Pydantic**: 数据验证和模型定义

### 模型服务
- **SiliconFlow API**: Qwen/Qwen3-30B-A3B-Instruct-2507（默认）
- **OpenAI兼容接口**: 支持本地部署的OpenAI兼容模型
- **Ollama**: 可选本地模型部署（已注释支持）
- **Whisper**: 语音识别模型，支持流式ASR
- **多模态模型**: 支持视觉理解的LLM（如Qwen2.5-VL）

### 语音处理
- **Whisper**: OpenAI开源语音识别模型
- **noisereduce**: 音频降噪处理
- **ffmpeg**: 音频格式转换
- **opencc**: 简繁体转换

### 数据存储
- **SQLite**: 生产环境推荐，支持事务和多用户
- **JSON文件**: 开发测试环境，简单易用

### 依赖库
- `langchain==1.0.5`: 代理框架核心
- `langchain-core==1.0.4`: LangChain核心库
- `langchain-classic==1.0.0`: LangChain经典组件
- `langchain-openai==1.0.2`: OpenAI模型集成
- `langchain-ollama==1.0.0`: Ollama模型集成
- `langgraph==1.0.3`: 工作流引擎
- `fastapi==0.122.0`: Web服务器
- `uvicorn==0.38.0`: ASGI服务器
- `requests==2.31.0`: HTTP客户端
- `pydantic==2.12.4`: 数据验证
- `PyYAML==6.0.1`: YAML配置解析
- `langchain_mcp_adapters==0.2.1`: mcp客户端适配器
- `python-docx==1.2.0`: word库
- `whisper`: OpenAI语音识别模型
- `openai==2.7.2`: OpenAI客户端
- `numpy==1.26.3`: 数值计算
- `noisereduce`: 音频降噪

## ⚡ 快速开始

### 环境准备
```bash
# 设置API密钥（使用SiliconFlow API）
export OPENAI_API_KEY="您的SiliconFlow API密钥"
# 或使用Dify知识库密钥
export DIFY_API_KEY="您的Dify API密钥"
严禁有空格
```

### Docker开发环境（推荐）
```bash
# 使用预配置的开发容器
docker run -d -p 8001:8001 -v $(pwd):/root/agentic-app --name langchain-agent-dev qingyanjiu/langchain:slim tail -f /dev/null
例子：
docker run -d -p 8001:8001 -v d:/work/Company_project/AI/ai-agentic-app:/root/agentic-app --name langchain-agent-dev qingyanjiu/langchain:slim tail -f /dev/null
docker run -d -p 8001:8001 -v d:\work\Company_project\AI\ai-agentic-app:/root/agentic-app --name langchain-agent-dev qingyanjiu/langchain tail -f /dev/null
docker run -d -p 8001:8001 -v d:\work\Company_project\AI\ai-agentic-app:/root/agentic-app  -v D:\work\models\bge-small-zh-v1.5:/root/agentic-app/agent/intent/models/BAAI_bge-small-zh-v1.5 -e INTENT_MODEL_PATH=/root/agentic-app/agent/intent/models/BAAI_bge-small-zh-v1.5   --name langchain-agent-dev qingyanjiu/langchain tail -f /dev/null
# 进入容器
docker exec -it langchain-agent-dev /bin/bash

# 在容器内启动服务
cd /root/agentic-app
python app.py 或者 python -m uvicorn app:app --host 0.0.0.0 --port 8001 --reload
```

### 本地启动
```bash
# 安装依赖（在虚拟环境中）
pip install -r requirements.txt

# 启动FastAPI服务器
python app.py
# 或使用uvicorn热重载
uvicorn app:app --host 0.0.0.0 --port 8000 --reload

# 访问API文档
# http://localhost:8000/docs
```


## 📖 API使用指南

### 1. 对话智能体 WebSocket 接口
系统通过WebSocket提供流式交互接口：
```javascript
const ws = new WebSocket('ws://localhost:8001/gen_doc/{user_id}/{session_id}');

ws.onopen = () => {
  // 发送生成请求
  ws.send(JSON.stringify({
   {
    "query": "理解下这图片",
    "image_url":"http://localhost:8001/uploads/c2deb3f4-7f40-4d70-8615-47de2dc060e7.png"
}  }))
};

```
**服务端响应格式**：
```json
{
	"event": "custom",
	"data": {
		"type": "intent_desc",
		"content": "之前的用户意图是：，最新的用户输入是：[{'type': 'text', 'text': '理解下这图片'}, {'type': 'image_url', 'image_url': {'url': 'http://127.0.0.1:8001/uploads/c2deb3f4-7f40-4d70-8615-47de2dc060e7.png'}}, '\\n', '[', '用', '户', '上', '传', '了', '图', '片', '，', '请', '结', '合', '图', '片', '理', '解', '意', '图', ']']"
	}
}
{
	"event": "custom",
	"data": {
		"type": "answer",
		"content": "好的，你上传的图片....."
	}
}
```
### 2. 语音转文字接口

上传图片并获取访问URL，用于后续的多模态识别：

```bash
const ws = new WebSocket('ws://localhost:8001/asr/{user_id}/{session_id}');

ws.onopen = () => {
  // 发送生成请求
  ws.send(JSON.stringify({
   {
     "action":"end",
    "voice_base64":"..."
}  }))
};
```

**响应格式**：
```json
{
    "event": "asr_final",
    "text": "今天天气很好",      
    "timestamp": ""
}
```

### 3. 图片上传接口

上传图片并获取访问URL，用于后续的多模态识别：

```bash
# 使用curl上传图片
curl -X POST "http://localhost:8001/upload/image" \
  -H "accept: application/json" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@/path/to/image.jpg"
```

**响应格式**：
```json
{
	"image_url": "http://127.0.0.1:8001/uploads/c2deb3f4-7f40-4d70-8615-47de2dc060e7.png",
	"filename": "c2deb3f4-7f40-4d70-8615-47de2dc060e7.png"
}
```

### 4. 文档生成 WebSocket 接口

```javascript
const ws = new WebSocket('ws://localhost:8001/gen_doc/{user_id}/{session_id}');

ws.onopen = () => {
  // 发送生成请求
  ws.send(JSON.stringify({
    query: 
    {
    "query": {
        "company": "设计院",
        "start_date": "2025-01-01",
        "end_date": "2025-12-31",
        "data":{
        "security": {
            "type": "安防",
            "date": "2025",
            "company": "A公司",
            "overview": {
                "total_month": 12,
                "total_alerts": 15717,
                "avg_monthly_alerts": 1309.75,
                "max_month": "2025-07",
                "min_month": "2025-02",
                "alert_type_ratio": {
                    "intrusion_alert": {
                        "ratio": "40.2%"
                    },
                    "abnormal_gathering_alert": {
                        "ratio": "34.8%"
                    },
                    "fire_alert": {
                        "ratio": "25.0%"
                    }
                },
                "severe_alerts": {
                    "count": 90.67
                },
                "face_recognition_match_rate": {
                    "rate": "92.9%"
                },
                "cctv_online_rate": {
                    "rate": "97.3%"
                },
                "key_events": "全年发生重大入侵事件32起，消防误报26起，主要集中在B栋办公区及园区北门",
                "root_cause": "夏季（7-8月）因人员流动频繁导致告警量偏高，春节、国庆假期因人员减少告警量显著下降"
            }
        },
        "energy": {
            "type": "能耗",
            "date": "2025",
            "overview": {
                "total_month": 12,
                "total_alerts": 15717,
                "avg_monthly_alerts": 1309.75,
                "max_month": "2025-07",
                "min_month": "2025-02",
                "alert_type_ratio": {
                    "intrusion_alert": {
                        "ratio": "40.2%"
                    },
                    "abnormal_gathering_alert": {
                        "ratio": "34.8%"
                    },
                    "fire_alert": {
                        "ratio": "25.0%"
                    }
                },
                "severe_alerts": {
                    "count": 90.67
                },
                "face_recognition_match_rate": {
                    "rate": "92.9%"
                },
                "cctv_online_rate": {
                    "rate": "97.3%"
                },
                "key_events": "全年发生重大入侵事件32起，消防误报26起，主要集中在B栋办公区及园区北门",
                "root_cause": "夏季（7-8月）因人员流动频繁导致告警量偏高，春节、国庆假期因人员减少告警量显著下降"
            }
        },
        "operation": {
            "type": "运营",
            "date": "2025",
            "overview": {
                "total_month": 12,
                "total_alerts": 15717,
                "avg_monthly_alerts": 1309.75,
                "max_month": "2025-07",
                "min_month": "2025-02",
                "alert_type_ratio": {
                    "intrusion_alert": {
                        "ratio": "40.2%"
                    },
                    "abnormal_gathering_alert": {
                        "ratio": "34.8%"
                    },
                    "fire_alert": {
                        "ratio": "25.0%"
                    }
                },
                "severe_alerts": {
                    "count": 90.67
                },
                "face_recognition_match_rate": {
                    "rate": "92.9%"
                },
                "cctv_online_rate": {
                    "rate": "97.3%"
                },
                "key_events": "全年发生重大入侵事件32起，消防误报26起，主要集中在B栋办公区及园区北门",
                "root_cause": "夏季（7-8月）因人员流动频繁导致告警量偏高，春节、国庆假期因人员减少告警量显著下降"
            }
        }}
    }

}
  }));
};

```

### 响应格式
```json
{
  "event": "token",
  "data": "AI生成的文本片段"
}
```
```json
{
  "event": "custom",
  "data": {
    "type": "tool",
    "content": "正在调用[查询知识库]工具..."
  }
}
```

## 🔧 配置说明

### global_config.json详解
系统所有配置都通过 `global_config.json` 管理：

```json
{
  "dify": {
    "datasets_api_key": "dataset-xxxxxxxxxxxxxx"
  },
  "memory_persistor": {
    "type": "sqlite",        // 可选: "sqlite" | "json" | "mysql" | "dm" ... json仅仅用来测试
    "memory_buffer_window": 3 // 记忆窗口大小，保留最近N轮对话
  }
}
```

### 环境变量配置
```bash
# 模型 API Key（DeepSeek / 任意 OpenAI 兼容服务；SILICON_API_KEY 已废弃）
export OPENAI_API_KEY="sk-xxxxxxxxxxxx"

# 模型服务URL（如需使用其他模型）
export MODEL_API_URL="https://api.siliconflow.cn/v1"
```

### 模型配置
模型配置在 `models/llm.py` 中定义：

```python
model_confs = [
    { 
        "name": "deepseek",  # 模型标识
        "type": "openai",   # API类型
        "model_url": "https://api.deepseek.com/v1",
        "model_name": "deepseek-flash",
        "api_key": os.getenv("OPENAI_API_KEY")
    },
    # 可添加其他模型配置...
]
```

### 工具配置
动态工具在 `dynamic_tools/dynamic-tools-data.json` 中配置：

```json
{
  "name": "query_knowledge_base",
  "displayName": "查询知识库",
  "description": "根据问题在知识库中进行语义检索",
  "endpoint": "http://.../retrieve",
  "method": "post",
  "parameters": {
    "properties": {
      "query": {"type": "string", "description": "查询关键词"}
    }
  }
}
```

### MCP服务器配置
MCP服务器在 `mcp_client/mcp_server_config.yaml` 中配置：

```yaml
mcp_servers:
  local:
    transport: streamable_http
    url: http://192.168.0.112:2222/mcp

  math_server:
    transport: stdio
    command: python
    args:
      - ./servers/math_server.py

  finance_server:
    transport: sse
    url: http://localhost:8002/mcp
    headers:
      Authorization: "Bearer YOUR_TOKEN"
```

支持的传输类型：`streamable_http`、`stdio`、`sse`

## 🔨 工具扩展指南

### 添加自定义工具
```python
from langchain_core.tools import tool
from pydantic import BaseModel, Field

# 定义参数模型
class CustomToolParams(BaseModel):
    param1: str = Field(description="参数1描述")
    param2: int = Field(description="参数2描述", default=10)

# 创建工具
@tool(args_schema=CustomToolParams, description="自定义工具描述")
def custom_tool(param1: str, param2: int = 10) -> str:
    """工具实现逻辑"""
    return f"处理结果: {param1}, {param2}"

# 添加到系统
TOOLS = [custom_tool] + existing_tools
```

### 扩展动态工具
1. 在 `dynamic-tools-data.json` 中添加工具定义
2. 系统启动时会自动加载新工具
3. 支持HTTP GET/POST方法，参数自动验证

### 集成外部API
```python
# 在dynamic_tools/中创建新的工具生成器
class APIDynamicTool(DynamicToolGenerator):
    def query_tool_info_list(self):
        # 从外部API或数据库获取工具列表
        return external_tool_list
    
    def tool_request(self, tool_name, parameters):
        # 调用外部API
        response = requests.post(api_url, json=parameters)
        return response.json()
```

### 集成MCP工具
系统支持通过MCP协议连接外部服务器，加载其提供的工具：

```python
from mcp_client.mcp_loader import get_mcp_tools

# 异步加载MCP工具
async def load_mcp_tools():
    tools = await get_mcp_tools("mcp_client/mcp_server_config.yaml")
    return tools

# 将MCP工具与其他工具合并
# all_tools = rag_tools + dynamic_tools + mcp_tools
```

配置MCP服务器时，需在 `mcp_server_config.yaml` 中定义服务器地址、传输协议和认证信息。

## 🧪 部署

### Docker生产部署
```dockerfile
# Dockerfile示例
FROM python:3.10-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

### 监控与日志
- 日志文件: `app.log` (详细debug信息)
- 可通过logging配置调整日志级别
- 建议生产环境使用集中式日志收集

## 📁 项目结构

```
agentic-app/
├── agent/                  # 代理相关模块，负责任务流程控制
│   ├── executor.py         # 代理执行器，封装了AgentExecutor，支持同步/异步执行
│   ├── ask_for_param_prompt.py # 生成请求用户补充信息的提示词
│   ├── info_double_check_prompts.py # 主要问答流程的系统提示词
│   ├── intent_get_prompt.py # 识别用户意图和工具的提示词
│   ├── get_intent_and_select_tools_prompt.py # 选择工具和获取参数的提示词
│   ├── intent/             # 意图识别与参数提取模块
│   │   ├── classifier.py   # Embedding 意图分类器（顶层意图 + 子类型判定）
│   │   ├── slots.py        # 参数(slot)抽取：时间/区域/餐次/人名/query_type
│   │   └── handlers/       # 各模块意图处理器（追问、相关性判断、缺失参数）
│   ├── text_corrector_prompt.py # 语音识别文本纠错提示词
│   └── rag_prompts.py      # RAG（检索增强生成）相关的系统提示词
├── asr/                    # 语音识别模块
│   ├── voice_asr.py        # Whisper语音识别核心，支持流式识别
│   ├── text_corrector.py   # 文本纠错器，支持pycorrector规则和LLM纠错
│   └── voice_recognizer.py # 语音识别封装类
├── graph/                  # 图形工作流模块，定义了工作流节点和流程
│   ├── reactive_pipeline.py # 反应式工作流的核心文件
│   ├── gen_doc_pipeline.py  # 文档生成工作流
│   ├── asr_pipeline.py      # 语音识别纠错工作流
│   ├── person_status_langgraph.py   # 人员态势 LangGraph 编排
│   ├── security_status_langgraph.py # 安防态势 LangGraph 编排
│   ├── canteen_status_langgraph.py  # 食堂管理 LangGraph 编排
│   ├── vehicle_status_langgraph.py  # 车辆态势 LangGraph 编排
│   └── langgraph开发模板代码.py # 模板参考文件
├── memory/                 # 记忆管理模块，用于持久化保存对话历史
│   ├── store.py            # 记忆存储服务，提供统一接口
│   ├── memory_persistor.py # 记忆持久化抽象基类
│   ├── memory_persistor_json.py # JSON持久化实现
│   └── memory_persistor_sqlite.py # SQLite持久化实现
├── tools/                  # 工具模块，包含具体的工具函数
│   ├── rag_tools.py        # RAG（检索增强生成）核心工具，实现了知识库检索
│   ├── custom_tool.py      # 自定义工具基类，用于生成动态工具
│   ├── system_tools.py     # 系统级工具的集合
│   └── dify_datasets_controller.py # Dify知识库控制器
├── dynamic_tools/          # 动态工具模块，支持从外部数据源动态加载工具
│   ├── api_dynamic_tool.py # 基于API的动态工具实现类
│   ├── file_dynamic_tool.py # 基于文件的动态工具实现类
│   ├── dynamic_tool_generator.py # 动态工具生成器，抽象基类
│   └── dynamic-tools-data.json # 工具描述数据文件
├── models/                 # 模型配置模块，管理大模型实例
│   └── llm.py              # 大模型工厂类，支持多种模型
├── static/                 # 静态文件目录
│   └── index.html          # 前端交互页面（语音识别）
├── app.py                  # 主应用入口，FastAPI服务器
├── global_config.json      # 全局配置文件
├── memory_store.json       # 内存存储的JSON文件
├── memory_store.db         # 内存存储的SQLite数据库文件
└── workflow.png            # 工作流图
```

### 核心目录说明

- **`asr/`**: 语音识别模块
  - `voice_asr.py`: Whisper模型封装，支持流式音频识别
  - `text_corrector.py`: 基于规则和LLM的文本纠错器
- **`graph/`**: 工作流模块
  - `asr_pipeline.py`: 语音识别纠错工作流
  - `gen_doc_pipeline.py`: 文档生成工作流


## 🔍 详细功能模块说明

### 1. `agent/` 模块
- **`executor.py`**：核心执行器。`AgentExecutorWrapper` 类封装了 LangChain 的 `AgentExecutor`，提供同步 `run()` 和异步 `stream_run()` 接口。它能根据配置选择使用 `MemoryStore` 读取持久化记录或使用 `ConversationBufferWindowMemory` 保持最近对话。
- **`rag_prompts.py`**：定义了RAG (Retrieval-Augmented Generation) 问答的系统提示词，指导LLM如何进行检索-精读-总结的完整流程。
- **`intent_get_prompt.py`**：专门用于判断用户意图和参数的提示词，系统通过分析对话历史和用户输入，精确提取参数。
- **`get_intent_and_select_tools_prompt.py`**：此提示词用于更复杂的意图获取，它会分析之前的意图，生成完整的调用逻辑说明和参数状态。
- **`ask_for_param_prompt.py`**：当参数不完整时，此提示词生成具体的、自然语言的询问，例如"请补充您想查询的区域信息"。

### 2. `graph/` 模块 (`reactive_pipeline.py`)
- **`InfoDoubleCheckPipeline` 类**：这是整个系统的核心。它使用 LangGraph 构建了一个状态机，定义了工作流的各个节点：`IntentGet` -> `AskForParam` -> `MainAgent` -> `Evaluator` -> `Composer`。
- **`MyState` 类型**：作为状态字典，管理整个流程中的关键状态，如 `query` (用户问题), `missing_params` (缺失参数), `intent_get_result` (意图获取结果), `evaluator_iter` (评估迭代次数) 等。
- **`evaulator_node` 方法**：调用大模型来评估 `MainAgent` 的回答是否充分，决定是否继续迭代。
- **`composer_node` 方法**：根据评估结果和中间输出，生成最终的、自然语言的合集答案，并支持流式输出。
- **`should_ask_for_param` 和 `should_redo_rag_after_evaluation`**：路由逻辑函数，控制工作流的分支流向。

### 3. `tools/` 模块
- **`rag_tools.py`**：核心工具集。包含 `query_knowledge_base` (通过语义搜索获取候选片段), `list_datasets` (获取知识库列表), `get_document_segments` (精读指定文档片段) 和 `list_documents` (列出文档) 等工具。所有工具均通过 `@tool` 装饰器定义，可被大模型直接调用。
- **`dify_datasets_controller.py`**：Dify知识库的适配层。它封装了与 Dify API 的交互逻辑，使得 `rag_tools.py` 可以方便地调用这些接口，无需关心具体实现。
- **`custom_tool.py`**：提供 `CustomTool` 基类，扩展了 LangChain 的 `StructuredTool`，添加了 `displayName` (显示名称) 和 `endPoint` (接口地址) 等字段，便于前端展示工具调用情况。

### 4. `dynamic_tools/` 模块
- **`file_dynamic_tool.py`**：一个具体的实现类。它继承自 `DynamicToolGenerator`，其 `query_tool_info_list` 方法从 `dynamic-tools-data.json` 文件中读取工具列表信息，并通过 `generate_tools` 方法将其转换为 LangChain 可识别的工具对象。这实现了"数据驱动"的工具加载。
- **`dynamic_tool_generator.py`**：抽象基类，定义了生成动态工具的通用接口，如 `query_tool_info_list` (获取工具列表) 和 `tool_request` (发起API请求)，并提供了 `get_tool_name_mapping` 和 `get_tool_json_desc` 等静态方法来获取工具元信息。
- **`dynamic-tools-data.json`**：关键的元数据文件。它以 JSON 格式定义了所有可用工具的详细信息，包括名称、显示名称、描述、API地址、参数等。系统在启动时会加载此文件，并以此为基础创建所有工具实例。

### 5. `memory/` 模块
- **`store.py`**：记忆存储的工厂类。`MemoryStore` 单例类根据配置 (`memory_persistor/type`) 选择使用 `MemoryPersistorJSON` 或 `MemoryPersistorSqlite` 实现。
- **`memory_persistor_json.py`**：一个仅用于开发测试的简易JSON持久化方案，不支持并发，仅作为演示。
- **`memory_persistor_sqlite.py`**：生产环境推荐的持久化方案。它使用SQLite数据库，通过`get_conn()`上下文管理器确保事务安全和连接关闭。该实现具备完整功能，支持多用户、多会话、数据持久化和内存窗口化（即: 只持久化最近的对话）。

### 6. `models/` 模块
- **`llm.py`**：大模型工厂。`CustomLLMFactory` 类初始化了多个大模型的实例（如 `deepseek` 和 `local`），并根据配置选择默认模型。这使得系统可以轻松切换不同的大模型，且支持 OpenAI 和 Ollama 两种后端。

### 7. `utils/` 模块
- **`utils.py`**：通用工具函数。`get_config()` 函数用于从 `global_config.json` 文件中读取全局配置。
- **`static.py`**：静态配置。定义了内存存储文件的路径，便于管理和维护。

### 8. `app.py` 模块
- **FastAPI 服务器**：主入口，提供多个 WebSocket 接口：
  - `/chat/{user_id}/{session_id}`: 对话智能体接口（支持多模态）
  - `/asr/{user_id}/{session_id}`: 语音识别接口
  - `/gen_doc/{user_id}/{session_id}`: 文档生成接口
  - `/upload/image`: 图片上传接口
- **静态文件服务**：
  - `/uploads/`: 上传文件访问
  - `/reports/`: 生成报告下载

### 9. `mcp_client/` 模块
- **`mcp_loader.py`**：MCP配置加载器。`load_mcp_config()` 函数从 YAML 文件读取 MCP 服务器配置，`get_mcp_tools()` 异步函数加载配置并通过 `MultiServerMCPClient` 获取 LangChain 兼容的工具列表。这实现了与多个 MCP 服务器的动态集成。
- **`mcp_server_config.yaml`**：MCP服务器配置文件。以 YAML 格式定义多个 MCP 服务器的连接信息，当前配置包含 `local` 服务器（使用 streamable_http 传输连接到指定 URL），支持扩展添加更多服务器。

### 10. `asr/` 语音识别模块
- **`voice_asr.py`**: Whisper语音识别核心模块
  - `AudioProcessor`: 音频格式转换（WebM→PCM）
  - `WhisperASR`: Whisper模型封装，支持噪声抑制和简繁体转换
  - `VoiceRecognizer`: 流式识别封装，支持多会话管理
  - 支持模型缓存和单例模式
- **`text_corrector.py`**: 文本纠错器
  - 支持 pycorrector 规则纠错
  - 支持 LLM 智能纠错（可选）
  - 简繁体转换
  - 专业术语保护

### 11. `graph/` 工作流模块
- **`asr_pipeline.py`**: 语音识别纠错工作流
  - `TextCorrectorPipeline`: 封装 LLM 纠错逻辑
  - 支持流式输出模拟
- **`gen_doc_pipeline.py`**: 文档生成工作流
  - 根据模板生成 Word 文档
  - 支持安防、能耗、运营等多类型报告
